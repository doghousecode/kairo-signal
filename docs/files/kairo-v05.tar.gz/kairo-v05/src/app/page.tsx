export default function Home() {
  return (
    <main style={{
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "linear-gradient(145deg, #080b14, #0b0f1a)",
      color: "white",
      fontFamily: "'Helvetica Neue', sans-serif",
    }}>
      <h1 style={{ fontSize: 48, fontWeight: 700, letterSpacing: -1 }}>
        K<span style={{ color: "#4F8EF7" }}>AI</span>RO
      </h1>
      <p style={{ color: "rgba(255,255,255,0.4)", marginTop: 8 }}>
        The right intelligence, at the right moment.
      </p>
      <p style={{ color: "rgba(255,255,255,0.2)", marginTop: 32, fontSize: 13 }}>
        v0.5 — Engine running
      </p>
    </main>
  );
}
