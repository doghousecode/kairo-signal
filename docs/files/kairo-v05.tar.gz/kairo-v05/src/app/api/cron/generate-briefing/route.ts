import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@/lib/supabase";
import { generateBriefing } from "@/lib/briefing-engine";
import { sendBriefingEmail } from "@/lib/email";

export const maxDuration = 60; // Allow up to 60s for generation

export async function GET(req: NextRequest) {
  // Verify cron secret (protects against random hits)
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const db = createServerClient();
    const userId = process.env.KAIRO_USER_ID!;

    // Get user email
    const { data: user } = await db
      .from("users")
      .select("email, name, timezone")
      .eq("id", userId)
      .single();

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Determine which pulse to generate based on current time
    const now = new Date();
    const hour = now.getUTCHours();
    // Simple logic: cron runs at 4am UTC, generate morning pulse
    const pulseType = hour < 10 ? "morning" : hour < 15 ? "midday" : "evening";

    // Check if we already generated this pulse today
    const today = now.toISOString().split("T")[0];
    const { data: existing } = await db
      .from("briefings")
      .select("id")
      .eq("user_id", userId)
      .eq("date", today)
      .eq("pulse_type", pulseType)
      .single();

    if (existing) {
      return NextResponse.json({
        message: `${pulseType} briefing already generated today`,
      });
    }

    // Generate briefing
    console.log(`[Kairo] Generating ${pulseType} briefing for ${user.name}...`);
    const briefing = await generateBriefing(userId, pulseType);

    // Save to database
    await db.from("briefings").insert({
      user_id: userId,
      date: today,
      pulse_type: pulseType,
      content_html: briefing.html,
      content_text: briefing.text,
      content_json: briefing.sections,
      sources_json: briefing.allSources,
      status: "generated",
      generated_at: new Date().toISOString(),
    });

    // Send email
    const subject = `Kairo ${pulseType} — ${new Date().toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" })}`;
    await sendBriefingEmail(user.email, subject, briefing.html, briefing.text);

    // Update status
    await db
      .from("briefings")
      .update({ status: "sent", sent_at: new Date().toISOString() })
      .eq("user_id", userId)
      .eq("date", today)
      .eq("pulse_type", pulseType);

    return NextResponse.json({
      success: true,
      pulse: pulseType,
      sections: briefing.sections.length,
      sources: briefing.allSources.length,
    });
  } catch (error: any) {
    console.error("[Kairo] Cron failed:", error);
    return NextResponse.json(
      { error: error.message || "Generation failed" },
      { status: 500 }
    );
  }
}
