import { NextRequest, NextResponse } from "next/server";
import { generateBriefing } from "@/lib/briefing-engine";
import { sendBriefingEmail } from "@/lib/email";
import { createServerClient } from "@/lib/supabase";

export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const pulseType = body.pulse || "morning";
    const sendEmail = body.send !== false; // default: send email
    const userId = process.env.KAIRO_USER_ID!;

    console.log(`[Kairo] Manual trigger: ${pulseType} pulse`);

    // Generate
    const briefing = await generateBriefing(userId, pulseType);

    // Optionally send email
    if (sendEmail) {
      const db = createServerClient();
      const { data: user } = await db
        .from("users")
        .select("email")
        .eq("id", userId)
        .single();

      if (user) {
        const subject = `[TEST] Kairo ${pulseType} — ${new Date().toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" })}`;
        await sendBriefingEmail(user.email, subject, briefing.html, briefing.text);
      }
    }

    return NextResponse.json({
      success: true,
      pulse: pulseType,
      sections: briefing.sections.map((s) => ({
        category: s.category,
        sourceCount: s.sources.length,
        contentLength: s.content.length,
      })),
      // Include HTML so you can preview in browser
      html: briefing.html,
    });
  } catch (error: any) {
    console.error("[Kairo] Manual generation failed:", error);
    return NextResponse.json(
      { error: error.message || "Failed" },
      { status: 500 }
    );
  }
}
