export const metadata = {
  title: "Kairo",
  description: "The right intelligence, at the right moment.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
