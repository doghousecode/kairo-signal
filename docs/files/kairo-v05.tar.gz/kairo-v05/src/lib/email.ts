import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendBriefingEmail(
  to: string,
  subject: string,
  html: string,
  text: string
) {
  const { data, error } = await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL || "Kairo <kairo@updates.yourdomain.com>",
    to,
    subject,
    html,
    text,
  });

  if (error) {
    console.error("[Kairo] Email send failed:", error);
    throw new Error(`Email failed: ${error.message}`);
  }

  console.log(`[Kairo] Email sent: ${data?.id}`);
  return data;
}
