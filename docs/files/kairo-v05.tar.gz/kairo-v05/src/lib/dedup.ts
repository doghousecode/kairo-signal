import { createServerClient } from "./supabase";
import crypto from "crypto";

export function hashStory(headline: string, source: string): string {
  // Normalise: lowercase, strip punctuation, first 100 chars
  const normalised = `${headline}|${source}`
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .slice(0, 100);
  return crypto.createHash("md5").update(normalised).digest("hex");
}

interface StoryCheck {
  headline: string;
  source: string;
  url: string;
}

interface DedupeResult {
  isNew: boolean;
  isEvolved: boolean;
  hash: string;
}

export async function checkStories(
  userId: string,
  stories: StoryCheck[]
): Promise<Map<string, DedupeResult>> {
  const db = createServerClient();
  const results = new Map<string, DedupeResult>();

  // Hash all stories
  const hashes = stories.map((s) => ({
    ...s,
    hash: hashStory(s.headline, s.source),
  }));

  // Fetch existing memory for these hashes
  const { data: existing } = await db
    .from("story_memory")
    .select("story_hash, headline, last_seen_at, evolution_count")
    .eq("user_id", userId)
    .in(
      "story_hash",
      hashes.map((h) => h.hash)
    );

  const existingMap = new Map(
    (existing || []).map((e) => [e.story_hash, e])
  );

  for (const story of hashes) {
    const prev = existingMap.get(story.hash);
    if (!prev) {
      results.set(story.hash, { isNew: true, isEvolved: false, hash: story.hash });
    } else {
      // Check if headline has meaningfully changed (simple: different length or words)
      const headlineChanged =
        story.headline.length !== prev.headline.length ||
        story.headline.toLowerCase() !== prev.headline.toLowerCase();
      results.set(story.hash, {
        isNew: false,
        isEvolved: headlineChanged,
        hash: story.hash,
      });
    }
  }

  return results;
}

export async function recordStories(
  userId: string,
  stories: { hash: string; headline: string; source: string; url: string }[],
  pulseType: string
) {
  const db = createServerClient();

  for (const story of stories) {
    await db.from("story_memory").upsert(
      {
        user_id: userId,
        story_hash: story.hash,
        headline: story.headline,
        source: story.source,
        url: story.url,
        last_seen_at: new Date().toISOString(),
        last_pulse: pulseType,
      },
      { onConflict: "user_id,story_hash" }
    );
  }
}
