interface TavilyResult {
  title: string;
  url: string;
  content: string;
  score: number;
}

interface TavilyResponse {
  results: TavilyResult[];
}

export async function searchNews(
  query: string,
  options?: {
    maxResults?: number;
    includeDomains?: string[];
    excludeDomains?: string[];
  }
): Promise<TavilyResult[]> {
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      api_key: process.env.TAVILY_API_KEY,
      query,
      max_results: options?.maxResults ?? 5,
      include_domains: options?.includeDomains ?? [],
      exclude_domains: options?.excludeDomains ?? [],
      search_depth: "advanced",
      include_answer: false,
    }),
  });

  if (!res.ok) {
    console.error("Tavily search failed:", res.status, await res.text());
    return [];
  }

  const data: TavilyResponse = await res.json();
  return data.results || [];
}
