import Anthropic from "@anthropic-ai/sdk";
import { createServerClient } from "./supabase";
import { searchNews } from "./tavily";
import { checkStories, recordStories, hashStory } from "./dedup";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

interface UserProfile {
  name: string;
  role: string;
  industry: string;
  company: string;
  timezone: string;
}

interface Interest {
  category: string;
  priority: number;
  depth: string;
  expertise: string;
  subcategories: Record<string, number>;
  trusted_sources: string[];
  blocked_sources: string[];
  locale: string;
}

interface BriefingSection {
  category: string;
  content: string;
  sources: { name: string; url: string }[];
}

interface BriefingResult {
  html: string;
  text: string;
  sections: BriefingSection[];
  allSources: { name: string; url: string }[];
}

// ─── Load user profile and interests ───
async function loadUserData(userId: string) {
  const db = createServerClient();

  const { data: user } = await db
    .from("users")
    .select("*")
    .eq("id", userId)
    .single();

  const { data: interests } = await db
    .from("user_interests")
    .select("*")
    .eq("user_id", userId)
    .order("priority", { ascending: false });

  return { user: user as UserProfile, interests: (interests || []) as Interest[] };
}

// ─── Build search queries per interest ───
function buildSearchQueries(interest: Interest): string[] {
  const queries: string[] = [];
  const today = new Date().toISOString().split("T")[0];

  // Base query for the category
  const categoryQueries: Record<string, string> = {
    news: "breaking news today UK world",
    ai_tech: "AI artificial intelligence technology news today",
    football: "football soccer news today",
    music: "music news releases today",
    politics: "politics news today",
    automotive: "cars automotive news today",
    fashion: "fashion streetwear culture news today",
    sports: "sports news results today",
    culture: "entertainment film TV culture news today",
    business: "business markets economy news today",
  };

  queries.push(categoryQueries[interest.category] || `${interest.category} news today`);

  // Add subcategory-specific queries for boosted subs
  const subs = interest.subcategories || {};
  for (const [subId, priority] of Object.entries(subs)) {
    if (priority >= 1) {
      // Boosted subs get their own search
      const subLabel = subId.replace(/_/g, " ");
      queries.push(`${subLabel} news today ${today}`);
    }
  }

  return queries;
}

// ─── Fetch news for all interests ───
async function fetchAllNews(interests: Interest[]) {
  const allResults: {
    category: string;
    results: { title: string; url: string; content: string; source: string }[];
  }[] = [];

  for (const interest of interests) {
    const queries = buildSearchQueries(interest);
    const categoryResults: { title: string; url: string; content: string; source: string }[] = [];

    for (const query of queries) {
      const results = await searchNews(query, {
        maxResults: interest.priority >= 2 ? 8 : interest.priority >= 1 ? 5 : 3,
        includeDomains: interest.trusted_sources.length > 0
          ? interest.trusted_sources.map(s => {
              // Convert source names to rough domain guesses
              const domainMap: Record<string, string> = {
                "BBC News": "bbc.co.uk", "BBC Sport": "bbc.co.uk",
                "The Guardian": "theguardian.com", "The Athletic": "theathletic.com",
                "Reuters": "reuters.com", "AP": "apnews.com",
                "Financial Times": "ft.com", "The Verge": "theverge.com",
                "Ars Technica": "arstechnica.com", "TechCrunch": "techcrunch.com",
                "Wired": "wired.com", "MIT Technology Review": "technologyreview.com",
                "Sky Sports": "skysports.com", "Pitchfork": "pitchfork.com",
                "NME": "nme.com", "Rolling Stone": "rollingstone.com",
                "The Economist": "economist.com", "Politico": "politico.com",
                "Top Gear": "topgear.com", "Autocar": "autocar.co.uk",
                "Highsnobiety": "highsnobiety.com", "GQ": "gq-magazine.co.uk",
                "Dazed": "dazeddigital.com",
              };
              return domainMap[s] || "";
            }).filter(Boolean)
          : undefined,
        excludeDomains: interest.blocked_sources.map(s => {
          const blockMap: Record<string, string> = {
            "The Sun": "thesun.co.uk", "Daily Mail": "dailymail.co.uk",
            "Daily Star": "dailystar.co.uk", "90min": "90min.com",
            "Caught Offside": "caughtoffside.com", "InfoWars": "infowars.com",
            "Breitbart": "breitbart.com", "New York Post": "nypost.com",
          };
          return blockMap[s] || "";
        }).filter(Boolean),
      });

      for (const r of results) {
        const domain = new URL(r.url).hostname.replace("www.", "");
        categoryResults.push({
          title: r.title,
          url: r.url,
          content: r.content.slice(0, 500),
          source: domain,
        });
      }
    }

    allResults.push({ category: interest.category, results: categoryResults });
  }

  return allResults;
}

// ─── Build the Claude prompt ───
function buildPrompt(
  user: UserProfile,
  interests: Interest[],
  newsData: { category: string; results: { title: string; url: string; content: string; source: string }[] }[],
  pulseType: string
): string {
  const depthInstructions: Record<string, string> = {
    headlines: "Keep it very brief. 1-2 sentences per story. Key facts only.",
    briefing: "Provide solid coverage. 2-4 sentences per story. Include context and significance.",
    deep_dive: "Go deep. 4-6 sentences per story. Analysis, implications, what it means for the reader.",
  };

  const expertiseInstructions: Record<string, string> = {
    explain: "Write accessibly. Define technical terms. Provide background context. Assume the reader is intelligent but not deeply familiar with this domain.",
    sharp: "Assume working knowledge of this domain. Skip basic context. Be direct and efficient.",
    expert: "Write at insider level. Use domain-specific terminology freely. Reference people, events, and trends without explaining them. No hand-holding.",
  };

  const localeInstructions: Record<string, string> = {
    UK: "Use British English spelling and phrasing. For football, teams are plural ('Arsenal are', not 'Arsenal is'). Reference UK-relevant context.",
    US: "Use American English.",
    Global: "Use internationally neutral English.",
  };

  let prompt = `You are Kairo, an AI chief of staff delivering a personalised ${pulseType} briefing.

READER PROFILE:
- Name: ${user.name}
- Role: ${user.role}
- Industry: ${user.industry}
- Company: ${user.company}
- Timezone: ${user.timezone}

TODAY'S DATE: ${new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}

BRIEFING TYPE: ${pulseType.toUpperCase()} PULSE
${pulseType === "morning" ? "This is the full daily briefing. Be comprehensive across all topics." : ""}
${pulseType === "midday" ? "This is the midday delta. Only cover what is NEW since the morning briefing. Be concise." : ""}
${pulseType === "evening" ? "This is the evening wrap. Summarise the day. What moved, what resolved, what to watch tomorrow." : ""}

TOPIC SECTIONS (generate in this order, by priority):
`;

  // Sort interests by priority (highest first)
  const sorted = [...interests].sort((a, b) => b.priority - a.priority);

  for (const interest of sorted) {
    const news = newsData.find((n) => n.category === interest.category);
    const subcats = Object.entries(interest.subcategories || {});
    const boostedSubs = subcats.filter(([, p]) => p >= 1).map(([id]) => id.replace(/_/g, " "));

    prompt += `
--- ${interest.category.toUpperCase()} ---
Priority: ${["standard", "elevated", "maximum"][interest.priority]}
Depth: ${interest.depth} — ${depthInstructions[interest.depth]}
Tone: ${interest.expertise} — ${expertiseInstructions[interest.expertise]}
Voice: ${localeInstructions[interest.locale] || "Use British English."}
${boostedSubs.length > 0 ? `Boosted sub-topics (give extra attention): ${boostedSubs.join(", ")}` : ""}
${subcats.length > 0 ? `Selected sub-topics: ${subcats.map(([id]) => id.replace(/_/g, " ")).join(", ")}` : ""}

Available news data:
${news?.results.map((r) => `- [${r.source}] ${r.title}\n  ${r.content}\n  URL: ${r.url}`).join("\n") || "No specific news found for this category."}
`;
  }

  prompt += `

OUTPUT FORMAT:
Return your briefing in the following JSON structure:
{
  "greeting": "A brief, warm, personalised one-line greeting for ${user.name}",
  "sections": [
    {
      "category": "category_id",
      "emoji": "relevant emoji",
      "title": "Section title",
      "content": "The briefing content for this section (use markdown for formatting)",
      "sources": [
        { "name": "Source Name", "url": "https://..." }
      ]
    }
  ],
  "sign_off": "A brief sign-off line"
}

RULES:
- Never repeat a story across sections
- Every claim must be sourced from the provided news data
- If no meaningful news exists for a category, include a brief "Nothing major today" note rather than fabricating content
- Match the depth and expertise level PRECISELY for each section — this is critical
- For UK locale football: Arsenal ARE, not Arsenal IS. Use British football terminology.
- Keep the overall tone confident, warm, and slightly editorial — like a trusted advisor, not a news ticker
- Return ONLY valid JSON, no markdown fences, no preamble
`;

  return prompt;
}

// ─── Generate briefing ───
export async function generateBriefing(
  userId: string,
  pulseType: string = "morning"
): Promise<BriefingResult> {
  // 1. Load user data
  const { user, interests } = await loadUserData(userId);
  if (!user || interests.length === 0) {
    throw new Error("User or interests not found");
  }

  // 2. Fetch news
  console.log(`[Kairo] Fetching news for ${interests.length} categories...`);
  const newsData = await fetchAllNews(interests);

  // 3. Dedup check
  const allStories = newsData.flatMap((n) =>
    n.results.map((r) => ({ headline: r.title, source: r.source, url: r.url }))
  );
  const dedupeResults = await checkStories(userId, allStories);

  // Filter out stories we have seen before (unless evolved)
  for (const category of newsData) {
    category.results = category.results.filter((r) => {
      const hash = hashStory(r.title, r.source);
      const check = dedupeResults.get(hash);
      return !check || check.isNew || check.isEvolved;
    });
  }

  // 4. Build prompt and call Claude
  const prompt = buildPrompt(user, interests, newsData, pulseType);
  console.log(`[Kairo] Calling Claude (prompt: ${prompt.length} chars)...`);

  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 4096,
    messages: [{ role: "user", content: prompt }],
  });

  const rawText =
    response.content[0].type === "text" ? response.content[0].text : "";

  // 5. Parse response
  let parsed;
  try {
    // Strip any markdown fences if present
    const cleaned = rawText.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    parsed = JSON.parse(cleaned);
  } catch (e) {
    console.error("[Kairo] Failed to parse Claude response:", rawText.slice(0, 200));
    throw new Error("Failed to parse briefing response");
  }

  // 6. Record stories in memory
  const storiesToRecord = newsData.flatMap((n) =>
    n.results.map((r) => ({
      hash: hashStory(r.title, r.source),
      headline: r.title,
      source: r.source,
      url: r.url,
    }))
  );
  await recordStories(userId, storiesToRecord, pulseType);

  // 7. Build HTML email
  const sections: BriefingSection[] = (parsed.sections || []).map((s: any) => ({
    category: s.category,
    content: s.content,
    sources: s.sources || [],
  }));

  const allSources = sections.flatMap((s) => s.sources);

  const html = buildEmailHtml(user.name, parsed.greeting, parsed.sections, parsed.sign_off, pulseType);
  const text = buildPlainText(parsed.greeting, parsed.sections, parsed.sign_off);

  return { html, text, sections, allSources };
}

// ─── HTML Email Template ───
function buildEmailHtml(
  name: string,
  greeting: string,
  sections: any[],
  signOff: string,
  pulseType: string
): string {
  const sectionHtml = sections
    .map(
      (s: any) => `
    <tr>
      <td style="padding: 24px 0; border-bottom: 1px solid #f0f0f0;">
        <p style="margin: 0 0 4px; font-size: 12px; color: #999; text-transform: uppercase; letter-spacing: 1px; font-family: 'Helvetica Neue', sans-serif;">
          ${s.emoji || ""} ${s.title}
        </p>
        <div style="font-size: 15px; line-height: 1.6; color: #333; font-family: Georgia, serif;">
          ${(s.content || "").replace(/\n/g, "<br>")}
        </div>
        ${
          s.sources && s.sources.length > 0
            ? `<p style="margin: 12px 0 0; font-size: 12px; color: #aaa; font-family: 'Helvetica Neue', sans-serif;">
            Sources: ${s.sources.map((src: any) => `<a href="${src.url}" style="color: #4F8EF7; text-decoration: none;">${src.name}</a>`).join(" &middot; ")}
          </p>`
            : ""
        }
      </td>
    </tr>`
    )
    .join("");

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin: 0; padding: 0; background: #fafafa; font-family: Georgia, serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background: #fafafa;">
    <tr>
      <td align="center" style="padding: 32px 16px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,0.06);">
          <!-- Header -->
          <tr>
            <td style="padding: 32px 32px 24px; background: linear-gradient(135deg, #0b0f1a, #141a2e); color: white;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td>
                    <span style="font-family: 'Helvetica Neue', sans-serif; font-size: 24px; font-weight: 700; letter-spacing: -0.5px;">
                      K<span style="color: #4F8EF7;">AI</span>RO
                    </span>
                  </td>
                  <td align="right">
                    <span style="font-family: 'Helvetica Neue', sans-serif; font-size: 12px; color: rgba(255,255,255,0.4); text-transform: uppercase; letter-spacing: 1px;">
                      ${pulseType} pulse
                    </span>
                  </td>
                </tr>
              </table>
              <p style="margin: 16px 0 0; font-size: 14px; color: rgba(255,255,255,0.6); font-family: 'Helvetica Neue', sans-serif;">
                ${new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
              </p>
            </td>
          </tr>
          <!-- Greeting -->
          <tr>
            <td style="padding: 28px 32px 8px;">
              <p style="margin: 0; font-size: 16px; color: #555; font-style: italic;">
                ${greeting}
              </p>
            </td>
          </tr>
          <!-- Sections -->
          <tr>
            <td style="padding: 0 32px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                ${sectionHtml}
              </table>
            </td>
          </tr>
          <!-- Sign off -->
          <tr>
            <td style="padding: 24px 32px 32px;">
              <p style="margin: 0; font-size: 14px; color: #999; font-family: 'Helvetica Neue', sans-serif;">
                ${signOff}
              </p>
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td style="padding: 20px 32px; background: #f8f8f8; border-top: 1px solid #eee;">
              <p style="margin: 0; font-size: 11px; color: #bbb; font-family: 'Helvetica Neue', sans-serif; text-align: center;">
                K<span style="color: #4F8EF7;">AI</span>RO &mdash; The right intelligence, at the right moment.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

function buildPlainText(greeting: string, sections: any[], signOff: string): string {
  let text = `KAIRO — ${new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}\n\n`;
  text += `${greeting}\n\n`;
  for (const s of sections) {
    text += `--- ${(s.emoji || "")} ${s.title} ---\n${s.content}\n`;
    if (s.sources?.length) {
      text += `Sources: ${s.sources.map((src: any) => `${src.name} (${src.url})`).join(", ")}\n`;
    }
    text += "\n";
  }
  text += `${signOff}\n`;
  return text;
}
